# ukuran asosiasi
if(!require(rcompanion)){install.packages("rcompanion")}
if(!require(vcd)){install.packages("vcd")}
if(!require(psych)){install.packages("psych")}
if(!require(DescTools)){install.packages("DescTools")}
if(!require(epitools)){install.packages("epitools")}

# manipulasi data
# bikin tabel kontingensi
if(!require(reshape2)){install.packages("reshape2")}
if(!require(dplyr)){install.packages("dplyr")}
if(!require(maditr)){install.packages("maditr")}

packages = c('rcompanion', 'vcd', 'psych', 'DescTools', 'epitools', 'reshape2', 'dplyr', 'maditr')
lapply(packages, library, character.only = TRUE)

setwd('E:/AED')
library(readxl)

data=read_excel('E:/AED/mtcarss2.xlsx')
mtcars2 <- within(data, {
  vs <- factor(vs, labels = c("V", "S"))
  am <- factor(am, labels = c("automatic", "manual"))
  cyl  <- ordered(cyl)
  gear <- ordered(gear)
  carb <- ordered(carb)
}) 

df_coba= mtcars2 %>%
  group_by(am,vs) %>%
head(mtcars2)
summary(mtcars2)

quantile(mtcars2$disp, probs = 0.25)

data2 = mtcars2 %>%
  group_by(am, vs) %>%
  summarise(jumlah = n())
data2 = dcast(data2, am ~ vs, value.var='jumlah')
data2

data_matrix = data.matrix(data2[ ,2:3])
data_matrix

# dari library psych
phi(data_matrix, digits = 4)

# dari library DescTools
# DescTools always produces a positive value.
Phi(data_matrix)

cramerV(data_matrix, digits = 4)

assocstats(data_matrix)

data_hist = matrix(c(table(mtcars2$am), table(mtcars2$vs)), nrow = 2)
rownames(data_hist) <- c('Automatic', 'Manual')
colnames(data_hist) <- c('V-shaped', 'Straight')
data_hist

barplot(data_hist,
        main = 'Stacked Barplot Engine & Transmission',
        col=c('#184E77','#1A759F'), 
        border="white", 
        xlab="Machine",
        ylim = c(0, 35),
        legend = rownames(data_hist))

barplot(data_hist,
        main = 'Grouped Barplot Engine & Transmission',
        col=c('#184E77','#1A759F'), 
        border="white",
        xlab="Machine",
        legend = rownames(data_hist),
        beside = T,
        ylim = c(0, 20))

plot(mtcars2$drat, mtcars2$wt, col='#184E77', pch=19,
     main = "Scatterplot of drat vs wt",
     xlab = "Rear axle ratio",
     ylab = "Weight (1000 lbs)",
     cex.axis = 1)
mtext(paste0('Korelasi = ', round(cor(mtcars2$drat, mtcars2$wt), digits = 2)), adj = .75, line = -7)

pairs.panels(mtcars2[,c(3:7)], 
             method = 'pearson', # correlation method
             hist.col = '#34A0A4',
             density = TRUE,  # show density plots
             ellipses = TRUE, # show correlation ellipses
             main = 'Pair plot of disp, hp, drat, wt, qsec')